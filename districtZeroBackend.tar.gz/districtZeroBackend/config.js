module.exports = {

    'authenticationSecret': 'districtzeroisawesome',
    'databaseURL': 'mongodb://localhost/districtZero'

};
